#' Información General del Dataset
#'
#' Brinda una información general del dataset teniendo en cuenta todas sus variables.
#' Aplica análisis exploratorio de datos (EDA), mostrando tipos de variables, resumen estadístico,
#' gráficos (histogramas o diagramas de barras), tablas de contingencia y análisis de asociaciones
#' entre variables categóricas.
#'
#' @param data Un data frame con los datos.
#' @param output_file Nombre del archivo HTML a generar.
#' @return Devuelve un informe HTML con los resultados del análisis y muestra recomendaciones en consola si aplica.
#' @import ggplot2 dplyr rmarkdown gmodels
#' @export
#' @examples
#' inf_gen(mtcars)

inf_gen <- function(data, output_file = "informe_eda.html") {
  if (!requireNamespace("rmarkdown", quietly = TRUE)) {
    stop("Necesitas instalar el paquete 'rmarkdown'")
  }

  if (!is.data.frame(data)) {
    stop("El argumento debe ser un data frame.")
  }

  # --- Recomendación previa ---
  numericas <- sapply(data, is.numeric)
  continuas <- sapply(data[, numericas, drop = FALSE], function(x) length(unique(x)) > 2)
  num_continuas <- sum(continuas)

  if (num_continuas > 2) {
    message("💡 Se encontraron",  num_continuas,  "variables numéricas continuas.\n")
    message("🔍 Se recomienda usar `extraer_continuas(data)` para realizar un análisis numérico más detallado.\n\n")
  }

  # --- Guardar data como .rds ---
  temp_rds <- tempfile(fileext = ".rds")
  saveRDS(data, temp_rds)

  # --- Archivo RMD para HTML ---
  temp_rmd <- tempfile(fileext = ".Rmd")

  writeLines(c(
    "---",
    "title: \"Informe EDA General\"",
    "output: html_document",
    "---",
    "",
    "```{r setup, include=FALSE, message=FALSE, warning=FALSE}",
    "knitr::opts_chunk$set(echo = FALSE, message = FALSE, warning = FALSE)",
    "library(ggplot2)",
    "library(dplyr)",
    "library(gmodels)",
    "library(knitr)",
    "library(DT)",
    paste0("data <- readRDS('", normalizePath(temp_rds, winslash = "/"), "')"),
    "```",
    "",
    "## Tipos de variables",
    "```{r}",
    "sapply(data, class)",
    "```",
    "",
    "## Resumen estadístico",
    "```{r}",
    "summary(data)",
    "```",
    "",
    "## Gráficos por variable",
    "```{r, results='hide'}",
    "for (var in names(data)) {",
    "  if (is.numeric(data[[var]])) {",
    "    print(ggplot(data, aes_string(x = var)) +",
    "      geom_histogram(bins = 30, fill = 'steelblue', color = 'white') +",
    "      ggtitle(paste('Histograma de', var)))",
    "  } else {",
    "    print(ggplot(data, aes_string(x = var)) +",
    "      geom_bar(fill = 'darkorange') +",
    "      ggtitle(paste('Diagrama de barras de', var)) +",
    "      theme(axis.text.x = element_text(angle = 45, hjust = 1)))",
    "  }",
    "}",
    "```",
    "",
    "## Tablas de contingencia y pruebas chi-cuadrado",
    "```{r}",
    "library(knitr)",
    "library(DT)",
    "cat_vars <- names(data)[sapply(data, function(x) is.character(x) || is.factor(x))]",
    "if (length(cat_vars) >= 2) {",
    "  for (i in 1:(length(cat_vars)-1)) {",
    "    for (j in (i+1):length(cat_vars)) {",
    "      v1 <- cat_vars[i]",
    "      v2 <- cat_vars[j]",
    "      cat('###', v1, 'vs', v2, '\\n\\n')",
    "      tab <- table(data[[v1]], data[[v2]])",
    "      if (nrow(tab) <= 30 && ncol(tab) <= 30) {",
    "        DT::datatable(as.data.frame.matrix(tab), options = list(scrollX = TRUE))",
    "      } else {",
    "        cat('Tabla demasiado grande para mostrar en forma interactiva.\\n\\n')",
    "      }",
    "      if (all(dim(tab) > 1)) {",
    "        cat('\\n**Prueba chi-cuadrado:**\\n\\n')",
    "        chisq <- chisq.test(tab)",
    "        knitr::kable(as.data.frame(t(chisq$expected)), caption = 'Valores Esperados')",
    "        print(chisq)",
    "      }",
    "      cat('\\n\\n')",
    "    }",
    "  }",
    "} else {",
    "  cat('No hay suficientes variables categóricas para analizar asociaciones.')",
    "}",
    "```"
  ), con = temp_rmd)

  output_file <- normalizePath(output_file, winslash = "/", mustWork = FALSE)

  rmarkdown::render(
    input = temp_rmd,
    output_file = output_file,
    quiet = TRUE
  )

  message("✅ Informe HTML generado en: ", output_file)
  browseURL(output_file)
}


#' Extraer variables numéricas continuas
#'
#' @description Esta función selecciona las columnas de un data frame que son numéricas continuas.
#' También guarda el resultado en un data llamada `data_num` en el entorno global.
#' @param data Un data frame.
#' @return Un data frame con solo las variables numéricas continuas.
#' @export
#'
#' @examples
#' extraer_continuas(mtcars)

extraer_continuas <- function(data) {
  if (!is.data.frame(data)) {
    stop("El argumento debe ser un data frame.")
  }

  # Selecciona columnas numéricas
  numericas <- sapply(data, is.numeric)

  # Filtra las numéricas que tienen más de 2 valores únicos
  continuas <- sapply(data[, numericas, drop = FALSE], function(col) length(unique(col)) > 2)

  # Extrae solo las columnas numéricas continuas
  continuas_df <- data[, names(continuas)[continuas], drop = FALSE]

  if (ncol(continuas_df) == 0) {
    message("No se encontraron variables numéricas continuas.")
  } else {
    assign("data_num", continuas_df, envir = .GlobalEnv)
    message("✅ Se guardó `data_num` en el entorno global con ", ncol(continuas_df), " variables.")
    message("👉 Ahora puede usar la función: inf_num(data_num)")
  }

  invisible(NULL)
}


#' Información general de variables numéricas continuas
#'
#' Brinda una información general del dataset para las variables numéricas continuas, incluyendo:
#' resumen estadístico, cantidad de valores nulos, detección de valores atípicos y visualización mediante boxplots.
#'
#' @param data Un data frame con variables numéricas continuas.
#' @param output_file Nombre del archivo HTML a generar.
#' @return Un informe HTML con los resultados del análisis y recomendaciones en consola.
#' @import ggplot2 dplyr rmarkdown knitr
#' @export
#'
#' @examples
#' inf_num(data_num)

inf_num <- function(data, output_file = "EDA_numericas.html") {
  if (!requireNamespace("rmarkdown", quietly = TRUE)) {
    stop("Debe instalar el paquete 'rmarkdown'")
  }

  # Guardar los datos en archivo temporal .rds
  temp_rds <- tempfile(fileext = ".rds")
  saveRDS(data, temp_rds)

  # Crear archivo Rmd temporal
  temp_rmd <- tempfile(fileext = ".Rmd")

  # Escribir el contenido del archivo Rmd
  rmd_code <- paste0(
    "---\n",
    "title: 'Información General: Variables Numéricas'\n",
    "output:\n",
    "  html_document:\n",
    "    toc: true\n",
    "    toc_depth: 2\n",
    "    theme: united\n",
    "---\n\n",

    "```{r setup, include=FALSE, warning=FALSE, message=FALSE}\n",
    "knitr::opts_chunk$set(echo = FALSE)\n",
    "library(ggplot2)\n",
    "library(dplyr)\n",
    "data <- readRDS('", normalizePath(temp_rds, winslash = "/"), "')\n",
    "```\n\n",

    "## Resumen Estadístico\n",
    "```{r}\n",
    "summary(data)\n",
    "```\n\n",

    "## Valores Nulos por Variable\n",
    "```{r}\n",
    "colSums(is.na(data))\n",
    "```\n\n",

    "## Valores Atípicos\n",
    "```{r}\n",
    "atipicos <- apply(data, 2, function(x) boxplot.stats(x)$out)\n",
    "# Mostrar la cantidad de valores atípicos por variable\n",
    "atipicos_count <- sapply(atipicos, length)\n",
    "cat('Cantidad de valores atípicos por variable:\\n')\n",
    "print(atipicos_count)\n",
    "```\n\n",

    "## Boxplots por Variable\n",
    "```{r, results='hide', warning=FALSE}\n",
    "for (col in names(data)) {\n",
    "  p <- ggplot(data, aes_string(y = col)) +\n",
    "    geom_boxplot(fill = 'lightblue') +\n",
    "    ggtitle(paste('Boxplot de', col)) +\n",
    "    theme_minimal()\n",
    "  suppressWarnings(print(p))\n",
    "}\n",
    "```\n"
  )

  writeLines(rmd_code, con = temp_rmd)

  output_file <- normalizePath(output_file, winslash = "/", mustWork = FALSE)

  rmarkdown::render(
    input = temp_rmd,
    output_file = output_file,
    quiet = TRUE
  )

  message("✅ Informe HTML generado en: ", output_file)
  browseURL(output_file)

  # Mostrar sugerencias en consola
  message("\n📌 Recomendación:")
  message("\n - Use la correlación de *Pearson* si las variables tienen distribución normal y relación lineal.\n")
  message("\n * Esta es la función si desea usar esa correlación cor_pearson(data_num).\n")
  message("\n- Use la correlación de *Spearman* si no hay normalidad o la relación es monótona.\n")
  message("\n * Esta es la función si desea usar esa correlación cor_spearman(data_num).\n")
}


#' Correlación de Pearson entre variables numéricas continuas y gráfico
#'
#' Calcula la correlación de Pearson entre las variables numéricas continuas o de una data y
#' genera un gráfico de la matriz de correlación.
#'
#' Es útil cuando las variables siguen una distribución normal y se busca medir
#' una relación lineal directa.
#'
#' @param data Un data frame con los datos.
#' @param vars Vector opcional con los nombres o posiciones de las variables a usar. Si es NULL, se usan todas las numéricas.
#' @return Un gráfico de la matriz de correlación y la matriz numérica.
#' @import ggplot2 corrplot dplyr
#' @export
#' @examples
#' cor_pearson(data_num)
#' cor_pearson(data_num, vars = c("var1", "var2"))

cor_pearson <- function(data, vars = NULL) {
  # Verificar si 'corrplot' está instalado
  if (!requireNamespace("corrplot", quietly = TRUE)) {
    stop("El paquete 'corrplot' es necesario para realizar la visualización de la correlación.")
  }

  # Selección de variables
  if (!is.null(vars)) {
    if (is.numeric(vars)) {
      data_sel <- data[, vars, drop = FALSE]
    } else if (is.character(vars)) {
      if (!all(vars %in% names(data))) {
        stop("Algunas de las variables especificadas no existen en el data frame.")
      }
      data_sel <- data[, vars, drop = FALSE]
    } else {
      stop("El parámetro 'vars' debe ser un vector de nombres (character) o posiciones (numeric).")
    }
  } else {
    data_sel <- dplyr::select(data, where(is.numeric))
  }

  # Verificación
  if (ncol(data_sel) < 2) {
    stop("Se requieren al menos dos variables numéricas para calcular la correlación.")
  }

  # Matriz de correlación de Pearson
  correlacion <- cor(data_sel, use = "complete.obs", method = "pearson")

  # Mostrar la matriz numérica
  cat("\n📈 Matriz de Correlación de Pearson (datos incompletos omitidos):\n")
  print(round(correlacion, 3))

  # Paleta
  paleta_colores <- colorRampPalette(c("#8B0000", "white", "#0033A0"))(200)

  # Graficar la matriz
  corrplot::corrplot(correlacion,
                     method = "color",
                     type = "upper",
                     col = paleta_colores,
                     tl.col = "black",
                     tl.cex = 0.8,
                     tl.srt = 45,
                     addCoef.col = "black",
                     number.cex = 0.6,
                     mar = c(1,1,4,1),
                     title = "Matriz de Correlación de Pearson")

  # Mensaje final
  message("\nℹ️ Nota: Se está realizando la correlación omitiendo los valores faltantes.\n")
  message("\n📌 Recomendación:\n")
  message("Después de visualizar las correlaciones, se sugiere aplicar la función `red_dim(data_num)` para realizar una reducción de dimensionalidad con PCA.\n")
}


#' Correlación de Spearman entre variables numéricas continuas y gráfico
#'
#' Calcula la correlación de Spearman entre las variables numéricas continuas seleccionadas o de un data y
#' genera un gráfico de la matriz de correlación.
#'
#' Es útil cuando las variables no siguen una distribución normal o cuando se espera que haya una relación
#' no lineal, pero aún monótona (es decir, que una variable aumenta o disminuye siempre que la otra lo haga).
#' Si las variables no son normales o se espera una relación no lineal, esta es la opción recomendada.
#'
#' @param data Un data frame con los datos.
#' @param vars Vector opcional con los nombres o posiciones de las variables a usar. Si es NULL, se usan todas las numéricas.
#' @return Un gráfico de la matriz de correlación y la matriz de correlación.
#' @import ggplot2 corrplot dplyr
#' @export
#'
#' @examples
#' cor_spearman(data_num)
#' cor_spearman(data_num, vars = c("var1", "var2"))

cor_spearman <- function(data, vars = NULL) {
  # Verificar si 'corrplot' está instalado
  if (!requireNamespace("corrplot", quietly = TRUE)) {
    stop("El paquete 'corrplot' es necesario para realizar la visualización de la correlación.")
  }

  # Selección de variables
  if (!is.null(vars)) {
    if (is.numeric(vars)) {
      data_sel <- data[, vars, drop = FALSE]
    } else if (is.character(vars)) {
      if (!all(vars %in% names(data))) {
        stop("Algunas de las variables especificadas no existen en el data frame.")
      }
      data_sel <- data[, vars, drop = FALSE]
    } else {
      stop("El parámetro 'vars' debe ser un vector de nombres (character) o posiciones (numeric).")
    }
  } else {
    data_sel <- dplyr::select(data, where(is.numeric))
  }

  # Verificación
  if (ncol(data_sel) < 2) {
    stop("Se requieren al menos dos variables numéricas para calcular la correlación.")
  }

  # Matriz de correlación de Spearman
  correlacion <- cor(data_sel, use = "complete.obs", method = "spearman")

  # Mostrar la matriz numérica
  cat("\n📈 Matriz de Correlación de Spearman (datos incompletos omitidos):\n")
  print(round(correlacion, 3))

  # Paleta
  paleta_colores <- colorRampPalette(c("#8B0000", "white", "#0033A0"))(200)

  # Graficar la matriz
  corrplot::corrplot(correlacion,
                     method = "color",
                     type = "upper",
                     col = paleta_colores,
                     tl.col = "black",
                     tl.cex = 0.8,
                     tl.srt = 45,
                     addCoef.col = "black",
                     number.cex = 0.6,
                     mar = c(1,1,4,1),
                     title = "Matriz de Correlación de Spearman")

  # Mensaje final
  message("\nℹ️ Nota: Se está realizando la correlación omitiendo los valores faltantes.\n")
  message("\n📌 Recomendación:\n")
  message("Después de visualizar las correlaciones, se sugiere aplicar la función `red_dim` para realizar una reducción de dimensionalidad con PCA.\n")
}



#' Reducción de dimensionalidad con PCA y clasificación jerárquica
#'
#' Esta función aplica Análisis de Componentes Principales (PCA) y clasificación jerárquica (HCPC)
#' a las variables numéricas continuas de un data frame.
#' Incluye visualización de los individuos en el espacio reducido, agrupación jerárquica y pruebas estadísticas.
#'
#' @param data Data frame que contiene las variables numéricas continuas previamente seleccionadas.
#' @param ncp Número de componentes principales a conservar (por defecto 2).
#' @param sample_size Número máximo de observaciones a usar. Por defecto 5000.
#' @param na_threshold Proporción máxima de NA permitida por columna. Por defecto 0.5.
#' @return Gráficos y resultados estadísticos en consola.
#' @import FactoMineR factoextra lawstat
#' @export
#' @examples
#' red_dim(data_num)

red_dim <- function(data, ncp = 2, sample_size = 5000, na_threshold = 0.5) {
  if (!requireNamespace("FactoMineR", quietly = TRUE) ||
      !requireNamespace("factoextra", quietly = TRUE) ||
      !requireNamespace("lawstat", quietly = TRUE)) {
    stop("Instala los paquetes 'FactoMineR', 'factoextra' y 'lawstat' para usar esta función.")
  }

  # Seleccionar columnas numéricas con proporción de NA menor al umbral
  data_numeric <- data[sapply(data, is.numeric)]
  columnas_validas <- colSums(is.na(data_numeric)) / nrow(data_numeric) < na_threshold
  data_valid <- data_numeric[, columnas_validas, drop = FALSE]

  if (ncol(data_valid) < 2) {
    stop("Se requieren al menos dos columnas numéricas válidas para realizar PCA.")
  }

  # Filtrar solo filas completamente observadas
  data_completa <- data_valid[complete.cases(data_valid), ]

  if (nrow(data_completa) < 5) {
    stop("No hay suficientes filas completas para aplicar PCA. Se requieren al menos 5.")
  }

  # Si hay muchas filas completas, tomar una muestra aleatoria
  if (nrow(data_completa) > sample_size) {
    data_muestra <- data_completa[sample(nrow(data_completa), sample_size), ]
  } else {
    data_muestra <- data_completa
  }

  # Guardar en entorno global con nuevo nombre
  assign("data_muestra", data_muestra, envir = .GlobalEnv)

  # Aplicar PCA sin imputación
  ACP <- FactoMineR::PCA(data_muestra, ncp = ncp, graph = FALSE)
  print(factoextra::fviz_pca_ind(
    ACP,
    label = "none",
    col.ind = "cos2",
    gradient.cols = c("#00AFBB", "#E7B800", "#FC4E07")
  ))

  message("\n✅ Se ha usado una muestra  aleatoria simple y con datos  completos para el PCA.\n")
  message(" Se ha guardado como 'data_muestra' en el entorno global.\n")
  message(" Puede usar la función gra_codo(data_muestra) para analizar el número óptimo de clusters.\n")
}



#' Gráfico del codo para determinar número óptimo de clusters con K-means
#'
#' Esta función calcula la suma de cuadrados intra-cluster (WSS) para varios valores de k
#' y genera el gráfico del codo (elbow plot), útil para determinar el número óptimo de clusters.
#' También sugiere el valor de k donde se detecta el mayor cambio de pendiente (codo).
#'
#' @param data Data frame con variables numéricas continuas.
#' @param max_k Número máximo de clusters a evaluar (por defecto 10).
#' @return Muestra un gráfico del codo y un mensaje recomendando el número de clusters.
#' @importFrom stats kmeans
#' @import ggplot2
#' @export
#' @examples
#' gra_codo(data_muestra)
gra_codo <- function(data, max_k = 10) {
  if (!requireNamespace("ggplot2", quietly = TRUE)) {
    stop("Necesitas instalar el paquete 'ggplot2'.")
  }

  # Validación
  if (!is.data.frame(data)) {
    stop("El argumento 'data' debe ser un data frame.")
  }

  if (any(!sapply(data, is.numeric))) {
    stop("Todos los datos deben ser numéricos.")
  }

  if (any(is.na(data))) {
    stop("Los datos no deben tener valores NA. Usa una función de imputación antes.")
  }

  # Calcular WSS para cada valor de k
  wss <- numeric(max_k)
  for (k in 1:max_k) {
    set.seed(123)
    kmeans_result <- kmeans(data, centers = k, nstart = 10)
    wss[k] <- kmeans_result$tot.withinss
  }

  # Calcular la segunda derivada para encontrar el "codo"
  dif1 <- diff(wss)
  dif2 <- diff(dif1)
  k_optimo <- which.max(abs(dif2)) + 1  # +1 por la doble diferencia

  # Crear dataframe para graficar
  df <- data.frame(Clusters = 1:max_k, WSS = wss)

  # Generar gráfico
  plot <- ggplot2::ggplot(df, ggplot2::aes(x = Clusters, y = WSS)) +
    ggplot2::geom_point(color = "#FC4E07", size = 3) +
    ggplot2::geom_line(color = "#00AFBB", linewidth = 1) +
    ggplot2::geom_vline(xintercept = k_optimo, linetype = "dashed", color = "gray40") +
    ggplot2::annotate("text", x = k_optimo + 0.5, y = max(wss)*0.9,
                      label = paste("k óptimo =", k_optimo),
                      color = "gray20", size = 4, hjust = 0) +
    ggplot2::labs(
      title = "Gráfico del Codo para K-means",
      x = "Número de Clusters (k)",
      y = "Suma de Cuadrados Intra-cluster (WSS)"
    ) +
    ggplot2::theme_minimal()

  # Mostrar gráfico
  print(plot)

  # Mensaje y retorno
  message("\n👉 Según el método del codo, el número óptimo de clusters es:", k_optimo, "\n")
  message(" Ahora puede usar la función k_means_pca(data_muestra) para realizar un clustering con el k sugerido o el que usted desee.\n")

}


#' K-Means usando componentes principales (PCA)
#'
#' Esta función aplica PCA a un conjunto de variables numéricas, selecciona las dos primeras
#' componentes principales y aplica K-Means con un número de clusters especificado o sugerido.
#' Se grafica la clasificación final de los individuos en el espacio de los componentes.
#'
#' @param data Data frame con variables numéricas continuas.
#' @param k Número de clusters (opcional). Si no se proporciona, se sugiere usando el método del codo.
#' @return Grafico del K-means.
#' @import FactoMineR
#' @import factoextra
#' @import ggplot2
#' @export
#' @examples
#' k_means_pca(data_muestra)

k_means_pca <- function(data, k = NULL) {
  if (!requireNamespace("FactoMineR", quietly = TRUE) ||
      !requireNamespace("factoextra", quietly = TRUE) ||
      !requireNamespace("ggplot2", quietly = TRUE)) {
    stop("Necesitas instalar los paquetes 'FactoMineR', 'factoextra' y 'ggplot2'.")
  }

  # PCA con 2 componentes
  pca_result <- FactoMineR::PCA(data, ncp = 2, graph = FALSE)
  pca_coords <- pca_result$ind$coord

  # Si no se especifica k, usar método del codo para sugerirlo
  if (is.null(k)) {
    wss <- numeric(10)
    for (i in 1:10) {
      set.seed(123)
      wss[i] <- kmeans(pca_coords, centers = i, nstart = 10)$tot.withinss
    }
    dif1 <- diff(wss)
    dif2 <- diff(dif1)
    k <- which.max(abs(dif2)) + 1
    message("\n✅ Número sugerido de clusters según el codo: ", k, "\n")
  }

  # Aplicar K-means con k clusters
  set.seed(123)
  km_result <- kmeans(pca_coords, centers = k, nstart = 25)

  # Graficar los clusters
  cluster_plot <- factoextra::fviz_cluster(
    list(data = pca_coords, cluster = km_result$cluster),
    geom = "point", ellipse.type = "convex", repel = TRUE,
    palette = "jco", ggtheme = ggplot2::theme_minimal()
  ) + ggplot2::labs(
    title = paste("K-Means con", k, "Clusters sobre PCA"),
    x = "Componente Principal 1", y = "Componente Principal 2"
  )

  # Mostrar solo el gráfico
  print(cluster_plot)

  # Mensaje de cierre después de mostrar el gráfico
  message("\n🎉 ¡Gracias por usar este paquete! La visualisación de PCA y clustering con K-means  ha sido completada.\n")
}


